-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 17 oct. 2023 à 09:32
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `0324`
--

-- --------------------------------------------------------

--
-- Structure de la table `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  `owner` int(11) NOT NULL,
  `completed` tinyint(4) DEFAULT NULL,
  `createdAt` date DEFAULT NULL,
  `updatedAt` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `task`
--

INSERT INTO `task` (`id`, `description`, `owner`, `completed`, `createdAt`, `updatedAt`) VALUES
(26, 'tache pipo 1', 3, 0, '2023-10-16', '2023-10-16'),
(27, 'tache pipo 2', 3, 0, '2023-10-16', '2023-10-16'),
(28, 'tache pipo 3', 3, 1, '2023-10-16', '2023-10-16'),
(29, 'tache pipo 4', 3, 1, '2023-10-16', '2023-10-16'),
(30, 'tache pipo 5', 3, 0, '2023-10-16', '2023-10-16');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(100) NOT NULL,
  `token` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `nom`, `age`, `email`, `password`, `token`) VALUES
(1, 'toto', 31, '', '', NULL),
(2, 'titi', 23, '', '', NULL),
(3, 'alain', 11, '', '', NULL),
(9, 'Mark', 36, 'marc@marc.com', '$2b$08$XPD787LKVh7nPQZAxSozZ.dCfp.g/BogUCIkSd', NULL),
(10, 'Mark', 36, 'toto@toto.com', '$2b$08$SVRWZfuC7rACykWaVVTaYOKS7uXFQpcggATSkz', NULL),
(11, 'titi', 36, 'titi@titi.com', '$2b$08$aeYgrTQatRR/YMWWTYYeXODyc07YkuzMm.gZ4O', NULL),
(12, 'tutu', 36, 'tutu@titi.com', '$2b$08$wSzGEMJjMy3SOYj3SNSILuEz1UM3SG0lW0hmwS', NULL),
(13, 'kiki', 36, 'kiki@kiki.com', '$2b$10$k.RfDOYIQlEdhDspU.Z/oOeud0XIJiP1W3wnwh', NULL),
(14, 'kiki', 36, 'koko@koko.com', '$2b$10$ww9zBasewYemIKSb.vyYhuI2EPpUbHyHM5F0Rh', NULL),
(15, 'kuku', 36, 'kuku@kuku.com', '$2b$10$r.lyNyvG1R1d8yfQsRmkAOPQ5Cm/LRNkixY16Rn5eCD6dESV1Qd/.', NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `Foreign Key` (`owner`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `task`
--
ALTER TABLE `task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `task`
--
ALTER TABLE `task`
  ADD CONSTRAINT `Foreign Key` FOREIGN KEY (`owner`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
